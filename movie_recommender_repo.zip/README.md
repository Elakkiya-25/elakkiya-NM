
# Movie Recommender Preprocessing Module

This repository contains preprocessing utilities for a movie recommendation system using both content-based and collaborative filtering techniques.

## Files

- `preprocessing_module.py` – Python script with functions for loading data, preprocessing, and extracting features.
- `ratings.csv` – Sample user ratings file (you need to provide your own data).
- `movies.csv` – Sample movie metadata file (you need to provide your own data).

## How to Use

1. Replace `ratings.csv` and `movies.csv` with your actual datasets.
2. Use the `preprocessing_module.py` functions to prepare the data for building a recommendation engine.

## Requirements

- pandas
- sklearn
- nltk

To install requirements:

```bash
pip install pandas scikit-learn nltk
```

